import { createStore } from 'redux';
// import favoriteReducer from './reducers.js';

const store = createStore();

export default store;
